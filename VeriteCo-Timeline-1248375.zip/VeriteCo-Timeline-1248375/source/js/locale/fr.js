// @codekit-prepend "VMM.Timeline.js";
/* LANGUAGE 
================================================== */
if(typeof VMM != 'undefined') {
	VMM.Language = {
		date: {
			month: ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"],
			month_abbr: ["janv.", "févr.", "mars", "avril", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "dec."],
			day: ["dimanche","lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"],
			day_abbr: ["dim.","lu.", "ma.", "me.", "jeu.", "vend.", "sam."],
		}, 
		dateformats: {
			year: "yyyy",
		    month_short: "mmm",
		    month: "mmmm yyyy",
		    full_short: "d mmm",
		    full: "d mmmm yyyy",
		    time_no_seconds_short: "HH:MM",
		    time_no_seconds_small_date: "HH:MM'<br/><small>'d mmmm yyyy'</small>'",
		    full_long: "dddd',' d mmm yyyy 'um' HH:MM",
		    full_long_small_date: "HH:MM'<br/><small>'dddd',' d mmm yyyy'</small>'"
		},
		messages: {
			loading_timeline: "Chargement de la frise en cours... ",
		    return_to_title: "Retour à la page d'accueil",
		    expand_timeline: "Elargir la frise",
		    contract_timeline: "Réduire la frise"
		}
	}
}